#include "SavingsAccount.h"

SavingsAccount::SavingsAccount() :BankAccount()
{
	InterestRate = 1.5;
}

SavingsAccount::SavingsAccount(double ir, int num, int bal, char* name, int d) :BankAccount(num, bal, name, d)
{
	InterestRate = ir;
}

int SavingsAccount::calculateInterest()
{
	int bal;
	bal = GetAccBalance();
	double interest;
	double x;
	x = InterestRate / 100;
	int t = GetDate();
	t = 2020 - t;
	interest = bal * (1 + (x * t));
	return interest;
}
void SavingsAccount::Deposit(int depo)
{
	int bal;
	bal = GetAccBalance();
	bal = bal + depo;
	double in = calculateInterest();
	bal = bal - in;
	SetAccBalance(bal);
}
void SavingsAccount::Withdraw(int wdraw)
{
	int bal = GetAccBalance();
	double in = calculateInterest();
	if (bal > wdraw)
	{
		bal = bal - wdraw;
		bal = bal - in;
		SetAccBalance(bal);
		}
	else
	{
		cout << "Insufficient Balance To WithDraw" << endl;
	}
}
void SavingsAccount::display()const
{
	BankAccount::Display();
	cout << "Interest Rate: " << InterestRate << endl;
	cout << "-----------------------" << endl;
}

double SavingsAccount::GetIR()const
{
	return InterestRate;
}
void SavingsAccount::SetIR(double ir)
{
	InterestRate = ir;
}
