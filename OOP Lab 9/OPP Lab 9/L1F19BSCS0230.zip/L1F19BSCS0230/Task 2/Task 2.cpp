#include<iostream>
#include"BankAccount.h"
#include"SavingsAccount.h"
#include"CheckingAccount.h"
using namespace std;
int main()
{
	int choice = 0;
	int depo;
	int wdraw;
	char* name = new char[20]{ 'M','u','s','a','\0' };
	cout << "Press 1.Checking Account" << endl;
	cout << "Press 2.Saving Account" << endl;
	cin >> choice;
	if (choice == 1)
	{
		CheckingAccount c_obj(20, 0230, 5000, name, 2001);
		c_obj.display();
		cout << endl;
		cout << "Enter Your choice" << endl;
		cout << "Press 1.Deposit" << endl;
		cout << "Press 2.WithDraw" << endl;
		cin >> choice;
		cout << endl;
		if (choice == 1)
		{	
			cout << "Enter Amount to Deposit: " << endl; cin >> depo;
			c_obj.Deposit(depo);
			cout << "Transaction Fee :" << c_obj.Getfee() << endl;
			cout << "After Transaction: " << endl;
			/*cout << endl;*/
			c_obj.display();
			cout << endl;
		}
		else /*if (choice == 2)*/
		{
			cout << "Enter Amount to Withdraw: "; cin >> wdraw;
			c_obj.Withdraw(wdraw);
			cout << "Transaction Fee :" << c_obj.Getfee() << endl;
			cout << "After Transaction " << endl;
			cout << endl;
			c_obj.display();
			cout << endl;
		}
	}
	else
	{
		SavingsAccount s_obj(1.9, 0230, 5000, name, 2001);
		s_obj.display();
		cout << endl;
		cout << "Enter Your choice" << endl;
		cout << "Press 1.Deposit" << endl;
		cout << "Press 2.WithDraw" << endl;
		cin >> choice;
		cout << endl;
		if (choice == 1)
		{
			cout << "Enter Amount to Deposit: " << endl; cin >> depo;
			s_obj.Deposit(depo);
			cout << "INTEREST RATE :" << s_obj.GetIR() << endl;
			cout << "After Interest Rate" << endl;
			/*cout << endl;*/
			s_obj.display();
			cout << endl;
		}
		else if (choice == 2)
		{
			cout << "Enter Amount to Withdraw: " << endl; cin >> wdraw;
			s_obj.Withdraw(wdraw);
			cout << "INTERESR RATE:" << s_obj.GetIR() << endl;
			cout << "After Interest Rate " << endl;
			/*cout << endl;*/
			s_obj.display();
			cout << endl;
		}
	}
	return 0;
}