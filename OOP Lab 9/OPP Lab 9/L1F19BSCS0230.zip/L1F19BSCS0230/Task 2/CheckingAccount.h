#pragma once
#include<iostream>
#include"BankAccount.h"
using namespace std;

class CheckingAccount:public BankAccount
{
private:
	int fee;
public:
	CheckingAccount();
	CheckingAccount(int f, int, int, char*, int);
	void Setfee(int f);
	int Getfee()const;
	void Withdraw(int wdraw);
	void Deposit(int depo);
	void display()const;
};

