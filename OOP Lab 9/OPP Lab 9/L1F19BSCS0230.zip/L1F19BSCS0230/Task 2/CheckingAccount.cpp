#include "CheckingAccount.h"
#include"BankAccount.h"

CheckingAccount::CheckingAccount() :BankAccount()
{
	fee = 25;
}

CheckingAccount::CheckingAccount(int f, int num, int bal, char* name, int D) :BankAccount(num, bal, name, D)
{
	fee = f;
}

void CheckingAccount::Setfee(int f)
{
	fee = f;
}


int CheckingAccount::Getfee()const
{
	return fee;
}

void CheckingAccount::Deposit(int depo)
{
	int bal = GetAccBalance();
	if (bal > fee)
	{
		bal = bal - fee;
		bal = bal + depo;
		SetAccBalance(bal);
	}
	else
	{
		cout << "INSUFFICIENT AMOUNT OF BALANCE" << endl;
	}

}
void CheckingAccount::Withdraw(int wdraw)
{
	int bal = GetAccBalance();
	if (bal > fee)
	{
		bal = bal - fee;
		if (bal > wdraw)
		{
			bal = bal - wdraw;
			SetAccBalance(bal);
		}
		else
		{
			SetAccBalance(bal);
			cout << "Insufficient Balance To WithDraw" << endl;
		}
	}
	else
	{

		cout << "INSUFFICIENT AMOUNT OF BALANCE" << endl;
	}
}
void CheckingAccount::display()const
{
	BankAccount::Display();
	cout << "Fee: "<<fee << endl;
	cout << "-----------------------" << endl;
}

