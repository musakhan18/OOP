#pragma once
#include<iostream>
using namespace std;
class BankAccount
{
private:
	char* AccTitle; 
	int AccNum, AccBalance, dateOfOpening;
public:
	BankAccount();
	BankAccount(int, int, char*, int);
	void SetAccTitle(char*);
	void SetAccNum(int);
	void SetAccBalance(int);
	void SetDate(int);
	int GetDate()const;
	char* GetAccTitle()const;
	int GetAccNum()const;
	int GetAccBalance()const;
	void Deposit(int);
	void Widraw(int);
	void Display()const;
	~BankAccount();
};

