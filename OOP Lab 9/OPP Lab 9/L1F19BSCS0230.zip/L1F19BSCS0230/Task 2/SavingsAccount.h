#pragma once
#include<iostream>
#include"BankAccount.h"
using namespace std;

class SavingsAccount:public BankAccount
{
private:
    double InterestRate;
public:
    SavingsAccount(); 
    SavingsAccount(double ir,int, int, char*, int);
    void SetIR(double ir);
    double GetIR()const;
    int calculateInterest();
    void Deposit(int depo);
    void Withdraw(int wdraw);
    void display()const;
};

