#include "BankAccount.h"

BankAccount::BankAccount()
{
	AccBalance =0;
	AccNum = 0;
	AccTitle = nullptr;
	dateOfOpening = 0;
}

BankAccount::BankAccount(int Num, int Bal, char* Title, int D)
{
	AccBalance = Bal;
	AccNum = Num;
	AccTitle = Title;
	dateOfOpening = D;
}

void BankAccount::SetAccTitle(char* Name)
{
	int s = 0;
	while (Name[s]!='\0')
	{
		s++;
	}
	AccTitle = new char[s + 1];
	for (int i = 0; i < s; i++)
	{
		AccTitle[i] = Name[i];
	}
	AccTitle[s] = '\0';
}

void BankAccount::SetDate(int D)
{
	dateOfOpening = D;
}

void BankAccount::SetAccNum(int Num)
{
	AccNum = Num;
}

void BankAccount::SetAccBalance(int Bal)
{
	AccBalance = Bal;
}

char* BankAccount::GetAccTitle()const
{
	int s = 0;
	while (AccTitle[s] != '\0')
	{
		s++;
	}
	char*Name = new char[s + 1];
	for (int i = 0; i < s; i++)
	{
		Name[i] = AccTitle[i];
	}
	Name[s] = '\0';
	return Name;
}

int BankAccount::GetAccNum()const
{
	return AccNum;
}

int BankAccount::GetAccBalance()const
{
	return AccBalance;
}

int BankAccount::GetDate()const
{
	return dateOfOpening;
}

void  BankAccount::Deposit(int depo)
{
	AccBalance = AccBalance + depo;
}
void BankAccount::Widraw(int wdraw)
{

	if (AccBalance > wdraw)
	{
		AccBalance = AccBalance - wdraw;
	}
	else
	{
		cout << "Insufficient Balance To WithDraw" << endl;
	}
}

void BankAccount::Display()const
{
	cout << endl;
	cout << "-----------------------" << endl;
	cout << "Account Title: " << AccTitle << endl;
	cout << "Account Number: " << AccNum << endl;
	cout << "Account Balance: " << AccBalance << endl;
	cout << "Account Date Of Opening: " << dateOfOpening << endl;
}

BankAccount::~BankAccount()
{
	delete[] AccTitle;
	AccTitle = nullptr;
}