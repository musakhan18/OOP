#include "Employee.h"

Employee::Employee():Person()
{
	salary = 0;
	employeeld = 0;
}

Employee::Employee(double S, int I, char* N, int A):Person( N, A)
{
	salary = S;
	employeeld = I;
}

void Employee:: SetSalary(double s)
{
	salary = s;
}
void Employee::SetEmployeeld(int I)
{
	employeeld = I;
}
double Employee::GetSalary()const
{
	return salary;
}

int Employee::GetEmployeeld()const
{
	return employeeld;
}

void Employee::display()const
{
	Person::display();
	cout << "Salary: " << salary << endl;
	cout << "Employee Id: " << employeeld << endl;
}