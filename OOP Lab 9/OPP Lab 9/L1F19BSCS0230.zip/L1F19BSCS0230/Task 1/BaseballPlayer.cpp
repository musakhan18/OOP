#include "BaseballPlayer.h"

BaseballPlayer::BaseballPlayer() :Person()
{
	battingAverage = 0;
	totalRuns = 0;
}

BaseballPlayer::BaseballPlayer(double BA, int TR, char* N, int A) :Person(N, A)
{
	battingAverage = BA;
	totalRuns = TR;
}

void BaseballPlayer::SetbattingAverage(double BA)
{
	battingAverage = BA;
}

void BaseballPlayer::SettotalRuns(int TR)
{
	totalRuns = TR;
}

double BaseballPlayer::GetbattingAverage()const
{
	return battingAverage;
}

int BaseballPlayer::GettotalRuns()const
{
	return totalRuns;
}

void BaseballPlayer::display()const
{
	Person::display();
	cout << "Batting Average: " << battingAverage << endl;
	cout << "Total Runs: " << totalRuns << endl;
}