#pragma once
#include<iostream>
#include"Person.h"
using namespace std;

class BaseballPlayer:public Person
{
private:
	double battingAverage;
	int totalRuns;
public:
	BaseballPlayer();
	BaseballPlayer(double, int, char*, int);
	void SetbattingAverage(double);
	void SettotalRuns(int);
	double GetbattingAverage()const;
	int GettotalRuns()const;
	void display()const;
};

