#pragma once
#include<iostream>
#include"Person.h"
using namespace std;

class Employee:public Person
{
	double salary;
	int employeeld;
public:
	Employee();
	Employee(double, int, char*, int);
	void SetSalary(double);
	void SetEmployeeld(int);
	double GetSalary()const;
	int GetEmployeeld()const;
	void display()const;
};

