#pragma once
#include<iostream>
using namespace std;
class Person
{
private:
	char* name;
	int age;
public:
	Person();
	Person(char*, int);
	void SetName(char*);
	void SetAge(int);
	char* GetName()const;
	int GetAge()const;
	void display()const;
	~Person();
};

