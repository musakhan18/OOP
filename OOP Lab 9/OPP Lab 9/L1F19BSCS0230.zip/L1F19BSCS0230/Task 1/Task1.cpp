#include<iostream>
#include"Person.h"
#include"Employee.h"
#include"BaseballPlayer.h"
using namespace std;
int main()
{
	char* name = new char[20]{ 'M','u','s','a','\0' };
	BaseballPlayer Player1(50, 1000, name, 20);
	Player1.display();
	cout << endl;
	Employee emp1(20000, 0230, name, 20);
	emp1.display();
	delete[] name;
	name = nullptr;
}